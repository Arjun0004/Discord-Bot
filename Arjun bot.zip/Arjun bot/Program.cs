﻿using System;
using System.Threading.Tasks;

namespace Arjun_bot
{
    class Program
    {
        public static async Task Main(string[] args)
            => await Startup.RunAsync(args);
        // this runs the startup class which will run the bot
    }
}