﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;

namespace Arjun_bot.Modules
{
    public class General : ModuleBase
    {
        [Command("hey")]
        public async Task Hello()
        {
            await Context.Channel.SendMessageAsync("Hello!");
            // If the user messages hey with our prefix the bot replies with hello
        }

        [Command("info")]
        public async Task UserInfo(SocketGuildUser user = null)
        {
            if (user == null)
            {
                var currentusername = Context.User.Username + "#" + Context.User.Discriminator;
                var builder = new EmbedBuilder()
                    .WithThumbnailUrl(Context.User.GetAvatarUrl() ?? Context.User.GetDefaultAvatarUrl())
                    .WithDescription("This is some info about yourself!")
                    .WithColor(new Color(13, 174, 189))
                    .AddField("Username", currentusername, true)
                    .AddField("User ID", Context.User.Id, true)
                    .AddField("IsBot", Context.User.IsBot, true)
                    .AddField("Created at", Context.User.CreatedAt.ToString("dddd, dd/MM/yyyy h:m tt"), true)
                    .AddField("Joined at", (Context.User as SocketGuildUser).JoinedAt.Value.ToString("dddd, dd/MM/yyyy h:m tt"), true)
                    .AddField("Roles:", string.Join(" ", (Context.User as SocketGuildUser).Roles.Select(x => x.Mention)))
                    .WithCurrentTimestamp();
                var embed = builder.Build();
                await Context.Channel.SendMessageAsync(null, false, embed);
            }
            else
            {
                var currentusername = user.Username + "#" + user.Discriminator;
                var builder = new EmbedBuilder()
                    .WithThumbnailUrl(user.GetAvatarUrl() ?? user.GetDefaultAvatarUrl())
                    .WithDescription($"This is some info about {user.Username}!")
                    .WithColor(new Color(13, 174, 189))
                    .AddField("Username", currentusername, true)
                    .AddField("User ID", user.Id, true)
                    .AddField("IsBot", user.IsBot, true)
                    .AddField("Created at", user.CreatedAt.ToString("dddd, dd/MM/yyyy h:m tt"), true)
                    .AddField("Joined at", user.JoinedAt.Value.ToString("dddd, dd/MM/yyyy h:m tt"), true)
                    .AddField("Roles:", string.Join(" ", user.Roles.Select(x => x.Mention)))
                    .WithCurrentTimestamp();
                var embed = builder.Build();
                await Context.Channel.SendMessageAsync(null, false, embed);
            }
            /* If the user types info with our prefix the bot replies with the date the user 
             joined your server, the date they created their discord account, if they're a bot a 
            small copy of their profile picture just for details, a description saying here is 
            some information about yourself, their username and discord ID. */
        }

        [Command("server")]
        public async Task Server()
        {
            var builder = new EmbedBuilder()
                .WithThumbnailUrl(Context.Guild.IconUrl)
                .WithDescription("This is some information about this server")
                .WithTitle($"{Context.Guild.Name} Information")
                .WithColor(new Color(105, 217, 20))
                .AddField("Created at", Context.Guild.CreatedAt.ToString("dd/MM/yyyy"))
                .AddField("Member Count", (Context.Guild as SocketGuild).MemberCount + " members", true)
                .AddField("Online users", (Context.Guild as SocketGuild).Users.Where(x => x.Status != UserStatus.Offline).Count() + " members", true);
            var embed = builder.Build();
            await Context.Channel.SendMessageAsync(null, false, embed);
            /* Gives info about the current server like, it gives a description callled This is 
             some information about this server, keeps the server icon as the thumbnail, keeps the
            title as the server name and Information, keeps a nice green colour for the embed, 
            gives the date created, total member count and online member count. */
        }
    }
}
