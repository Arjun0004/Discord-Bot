﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord.Commands;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using Discord;

namespace Arjun_bot.Modules
{
    public class Fun : ModuleBase
    {
        [Command("meme")]
        [Alias("reddit")]
        /*This is a bit weird, but what we are doing here is making a alias which is same as memes
         but becomes different if we add something for it to do.. IDK just check the code you'll 
        get it. */
        public async Task Meme(string subreddit = null)
        {
            
            var client = new HttpClient();
            var result = await client.GetStringAsync($"https://reddit.com/r/{subreddit ?? "memes"}/random.json?limit=1");

            if (!result.StartsWith("["))
            {
                await Context.Channel.SendMessageAsync("This subreddit doesn't exist!");
                return;
            }
            /* Made a http client to get the url links from.. if the user inputs no subreddit and 
            only the comman then it's going to select and give a random meme from the memes 
            subreddit and if the user does select a subreddit it gives a meme from that subreddit. */
            JArray arr = JArray.Parse(result);
            JObject post = JObject.Parse(arr[0]["data"]["children"][0]["data"].ToString());
            // Cutting out the unessecary data

            var builder = new EmbedBuilder()
                .WithImageUrl(post["url"].ToString())
                .WithColor(new Color(13, 174, 189))
                .WithTitle(post["title"].ToString())
                .WithUrl("https://reddit.com" + post["permalink"].ToString())
                .WithFooter($"🗨 {post["num_comments"]} ⬆️ {post["ups"]}");
            var embed = builder.Build();
            await Context.Channel.SendMessageAsync(null, false, embed);
            // Creating and building an embed with the meme, comments and number of upvotes
        }
    }
}
