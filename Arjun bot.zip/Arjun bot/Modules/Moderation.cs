﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;

namespace Arjun_bot.Modules
{
    public class Moderation : ModuleBase
    {
        [Command("purge")]
        [RequireUserPermission(GuildPermission.ManageMessages)]
        /* This says that if the uesr has ManageMessages permission in the discord server settings
         they will be able to use this command. Otherwise they can't use this command. */
        public async Task CleanMessages(int amount)
        // This stores the number of messages we want to delete using the bot.
        {
            var messages = await Context.Channel.GetMessagesAsync(amount + 1).FlattenAsync();
            await (Context.Channel as SocketTextChannel).DeleteMessagesAsync(messages);
            /* This gets the amount of messages we want to delete using the bot and deletes those
            messages. */

            var message = await Context.Channel.SendMessageAsync($"{messages.Count()} messages deleted successfully");
            await Task.Delay(2500);
            await message.DeleteAsync();
            /* Sends the user a messages saying the amount of messages were deleted succesfully 
             and deletes that messages after 2.5 seconds. */
        }
    }
}
