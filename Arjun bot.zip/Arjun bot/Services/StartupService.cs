﻿using Discord.WebSocket;
using Discord.Commands;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Discord;
using System.Reflection;

namespace Arjun_bot.Services
{
    public class StartupService
    {
        public static IServiceProvider _provider;
        private readonly DiscordSocketClient _discord;
        private readonly CommandService _commands;
        private readonly IConfigurationRoot _config;

        public StartupService(IServiceProvider provider, DiscordSocketClient discord, CommandService commands, IConfigurationRoot config)
        {
            _provider = provider;
            _config = config;
            _discord = discord;
            _commands = commands;
            // We are taking all the things our bot should do and making them ready I guess?
        }

        public async Task StartAsync()
        {
            string token = _config["tokens:discord"];
            if (string.IsNullOrEmpty(token))
            {
                Console.WriteLine("Please provide your discord token in _congif.yml");
                return;
            }
            /* Checks if our bot has the token in it to login into discord, if it has token it'll 
            be sent down to login into discord, if not it's going to print a message in the 
            console saying "Please provider your discord token in _config.yml". */

            await _discord.LoginAsync(TokenType.Bot, token);
            // This tells the program that the account we're using is to login a bot
            await _discord.StartAsync();

            await _commands.AddModulesAsync(Assembly.GetEntryAssembly(), _provider);
        }
    }
}
