﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arjun_bot.Services
{
    public class CommandHandler
    {
        public static IServiceProvider _provider;
        public static DiscordSocketClient _discord;
        public static CommandService _commands;
        public static IConfigurationRoot _config;

        public CommandHandler(DiscordSocketClient discord, CommandService commands, IConfigurationRoot config, IServiceProvider provider)
        {
            _provider = provider;
            _config = config;
            _discord = discord;
            _commands = commands;
            // All of the above stuff is the same as we did in StartupService.cs

            _discord.Ready += OnReady;
            _discord.MessageReceived += OnMessageReceived;
            _discord.ReactionAdded += OnReactionAdded;

            _discord.ChannelCreated += OnChannelCreated;
            _discord.JoinedGuild += OnJoinGuild;
        }

        private async Task OnReactionAdded(Cacheable<IUserMessage, ulong> arg1, ISocketMessageChannel arg2, SocketReaction arg3)
        {
            if (arg3.MessageId != 802076828553969704) return;
            // Checks if the user is adding the reaction to the correct message

            if (arg3.Emote.Name != "✅") return;
            // Checks if the user is adding the correct reaction to the message

            var role = (arg2 as SocketGuildChannel).Guild.Roles.FirstOrDefault(x => x.Id == 764366740326449162);
            await (arg3.User.Value as SocketGuildUser).AddRoleAsync(role);
            // If so, it gets the role we want to add.. and adds it to the user.
        }

        private async Task OnJoinGuild(SocketGuild arg)
        {
            await arg.DefaultChannel.SendMessageAsync("Thank you for using my Discord Bot!");
            // This sends a message to the server it joined saying "Thank you for using my Bot!"
        }

        private async Task OnChannelCreated(SocketChannel arg)
        {
            if ((arg as ITextChannel) == null) return;
            var channel = arg as ITextChannel;

            await channel.SendMessageAsync("The event was called");
            // This sends a message saying "The event was called" if a new channel is created;
        }

        private async Task OnMessageReceived(SocketMessage arg)
        {
            var msg = arg as SocketUserMessage;

            if (msg.Author.IsBot) return;
            /* sees if the author of the message is a bot and if it is a bot it doesn't let it run
            * the command*/

            var context = new SocketCommandContext(_discord, msg);
            int pos = 0;

            if (msg.HasStringPrefix(_config["prefix"], ref pos))
            /* Checks if the message has the prefix of our bot, if it has the prefix then it 
             * continues to the next part. */
            {
                var result = await _commands.ExecuteAsync(context, pos, _provider);

                if (!result.IsSuccess)
                {
                    var reason = result.Error;

                    await context.Channel.SendMessageAsync($"The following error occured: \n{reason}");
                    Console.WriteLine(reason);
                    // If there is an error, it tells the user and the console what error it is
                }
            }
        }

        private Task OnReady()
        {
            /* This prints our bot's username and the number which is beside the hashtag for every
             discord user on the console. To tell use that the bot is ready to be used. */
            Console.WriteLine($"Connected as {_discord.CurrentUser.Username}#{_discord.CurrentUser.Discriminator}");
            return Task.CompletedTask;
        }
    }
}
