﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Discord.WebSocket;
using Discord.Commands;
using Arjun_bot.Services;

namespace Arjun_bot
{
    class Startup
    {
        public IConfigurationRoot Configuration { get; }
        // this variable will help to build the bot

        public Startup(string[] args)
        {
            var builder = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddYamlFile("_config.yml");
            Configuration = builder.Build();
            // This is a small class which builds the bot using Configuration variable
        }

        public static async Task RunAsync(string[] args)
        {
            var startup = new Startup(args);
            await startup.RunAsync();
            /* This is a function which creates an infinite loop and what it does is, if the is
             done with the command it starts over again so the user can type the next command. */
        }

        public async Task RunAsync()
        {
            var services = new ServiceCollection();
            // We make a variable to store our services
            ConfigureService(services);

            var provider = services.BuildServiceProvider();
            provider.GetRequiredService<CommandHandler>();
            /* This builds up the services just like the Configuration variable, now we can use
            the services through our bot (We use it with our bot because services won't work 
            until you have an account or something like that*/

            await provider.GetRequiredService<StartupService>().StartAsync();
            await Task.Delay(-1);
            /* This makes our bot online and gives it an infinite delay so it stays online till 
            the console through which the bot is being online is closed.  */
        }

        private void ConfigureService(IServiceCollection services)
        {
            services.AddSingleton(new DiscordSocketClient(new DiscordSocketConfig
            // This is the collection of services containing all the settings and stuff
            {
                LogLevel = Discord.LogSeverity.Verbose,
                /* If log loglevel is high, then we get more information. If it's low then we get
                 less information about anything which goes wrong */
                MessageCacheSize = 1000
                /* This is the message size of the log. This makes sure that the messages don't 
                go over the cache of 1000 */
            }))
            .AddSingleton(new CommandService(new CommandServiceConfig
            {
                LogLevel = Discord.LogSeverity.Verbose,
                DefaultRunMode = RunMode.Async,
                /* This makes sure that the next command is executed, when the previous one is 
                finished. */
                CaseSensitiveCommands = false
                /* If this was true it would decline any commands with wrong capitalization and
                 stuff like that*/
            }))
            .AddSingleton<CommandHandler>()
            .AddSingleton<StartupService>()
            .AddSingleton(Configuration);
            // This makes sure that it's satisfying all the rules of these 3 services
        }
    }
}