﻿using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Microsoft.Extensions.Logging;

namespace Template.Modules
{
    public class ExampleModule : ModuleBase<SocketCommandContext>
    {
        [Command("ping")]
        public async Task PingAsync()
        {
            await ReplyAsync("Pong!");
        }

        [Command("echo")]
        [Alias("repeat", "say")]
        public async Task EchoAsync([Remainder] string text)
        {
            await ReplyAsync(text);
        }

        [Command("math")]
        public async Task MathAsync([Remainder] string math)
        {
            var dt = new DataTable();
            var result = dt.Compute(math, null);
            
            await ReplyAsync($"Result: {result}");
        }

        [Command("hey")]
        [Alias("hello", "hi")]
        public async Task Reply()
        {
            System.Random randomNum = new System.Random();
            int randomNum2 = randomNum.Next(1, 8);

            if (randomNum2 == 1 || randomNum2 == 2)
            {
                await Context.Channel.SendMessageAsync("Hey");
            }
            else if (randomNum2 == 3 || randomNum2 == 4)
            {
                await Context.Channel.SendMessageAsync("Hello");
            }
            else if (randomNum2 == 5 || randomNum2 == 6)
            {
                await Context.Channel.SendMessageAsync("Hi");
            }
            else if (randomNum2 == 7)
            {
                await Context.Channel.SendMessageAsync("Hallo :D");
            }
            /* If the user sends a message saying Hey, Hello or Hi.. The bot first generates a 
             random number, and it checks in the if statement for which message to send, and sends
            that message. */
        }

        [Command("info")]
        public async Task UserInfo(SocketGuildUser user = null)
        {
            if (user == null)
            {
                var currentusername = Context.User.Username + "#" + Context.User.Discriminator;
                var builder = new EmbedBuilder()
                    .WithThumbnailUrl(Context.User.GetAvatarUrl() ?? Context.User.GetDefaultAvatarUrl())
                    .WithDescription("This is some info about yourself!")
                    .WithColor(new Color(13, 174, 189))
                    .AddField("Username", currentusername, true)
                    .AddField("User ID", Context.User.Id, true)
                    .AddField("IsBot", Context.User.IsBot, true)
                    .AddField("Created at", Context.User.CreatedAt.ToString("dddd, dd/MM/yyyy h:m tt"), true)
                    .AddField("Joined at", (Context.User as SocketGuildUser).JoinedAt.Value.ToString("dddd, dd/MM/yyyy h:m tt"), true)
                    .AddField("Roles:", string.Join(" ", (Context.User as SocketGuildUser).Roles.Select(x => x.Mention)))
                    .WithCurrentTimestamp();
                var embed = builder.Build();
                await Context.Channel.SendMessageAsync(null, false, embed);
            }
            else
            {
                var currentusername = user.Username + "#" + user.Discriminator;
                var builder = new EmbedBuilder()
                    .WithThumbnailUrl(user.GetAvatarUrl() ?? user.GetDefaultAvatarUrl())
                    .WithDescription($"This is some info about {user.Username}!")
                    .WithColor(new Color(13, 174, 189))
                    .AddField("Username", currentusername, true)
                    .AddField("User ID", user.Id, true)
                    .AddField("IsBot", user.IsBot, true)
                    .AddField("Created at", user.CreatedAt.ToString("dddd, dd/MM/yyyy h:m tt"), true)
                    .AddField("Joined at", user.JoinedAt.Value.ToString("dddd, dd/MM/yyyy h:m tt"), true)
                    .AddField("Roles:", string.Join(" ", user.Roles.Select(x => x.Mention)))
                    .WithCurrentTimestamp();
                var embed = builder.Build();
                await Context.Channel.SendMessageAsync(null, false, embed);
            }
            /* If the user types info with our prefix the bot replies with the date the user 
             joined your server, the date they created their discord account, if they're a bot a 
            small copy of their profile picture just for details, a description saying here is 
            some information about yourself, their username and discord ID. */
        }

        [Command("server")]
        [Alias("server info")]
        public async Task Server()
        {
            var builder = new EmbedBuilder()
                .WithThumbnailUrl(Context.Guild.IconUrl)
                .WithDescription("This is some information about this server")
                .WithTitle($"{Context.Guild.Name} Information")
                .WithColor(new Color(105, 217, 20))
                .AddField("Created at", Context.Guild.CreatedAt.ToString("dd/MM/yyyy"))
                .AddField("Member Count", (Context.Guild as SocketGuild).MemberCount + " members", true)
                .AddField("Online users", (Context.Guild as SocketGuild).Users.Where(x => x.Status != UserStatus.Offline).Count() + " members", true);
            var embed = builder.Build();
            await Context.Channel.SendMessageAsync(null, false, embed);
            /* Gives info about the current server like, it gives a description callled This is 
             some information about this server, keeps the server icon as the thumbnail, keeps the
            title as the server name and Information, keeps a nice green colour for the embed, 
            gives the date created, total member count and online member count. */
        }
    }
}